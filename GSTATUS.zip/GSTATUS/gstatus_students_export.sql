-- GSTATUS Student Database Export
-- Generated: 2025-01-11
-- Total Students: 583
-- Covers: Floor 1 (101-114), Floor 2 (201-214), Floor 3 (301-312)

-- Create table structure
CREATE TABLE IF NOT EXISTS students (
    id SERIAL PRIMARY KEY,
    student_id VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    room VARCHAR(20) NOT NULL,
    floor VARCHAR(10) NOT NULL,
    points INTEGER DEFAULT 0,
    grade VARCHAR(10) DEFAULT 'D',
    remark VARCHAR(255),
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Clear existing data (if any)
DELETE FROM students;

-- Insert all student data('AB4980', 'CHUNCHU LALITH ADITHYA', '209/2', '2', 0, 'D', true, NOW(), NOW()),                           +
('AB6567', 'Somesh Parganiha', '209/6', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AB8929', 'K. Sathwik Sangvi', '208/12', '2', 0, 'D', true, NOW(), NOW()),                               +
('AC3177', 'GOLLAPALLY DHANUSH REDDY', '202/1', '2', 0, 'D', true, NOW(), NOW()),                         +
('AC3178', 'GOLLAPALLY MEGHANATH REDDY', '111/3', '1', 0, 'D', true, NOW(), NOW()),                       +
('AC3582', 'CHINNABABAU BAJARAG SOMESH', '110/13', '1', 0, 'D', true, NOW(), NOW()),                      +
('AC5367', 'P PRASANTH KUMAR', '309/14', '3', 0, 'D', true, NOW(), NOW()),                                +
('AC5368', 'KONDAVENI SRI HARSHA', '303/10', '3', 0, 'D', true, NOW(), NOW()),                            +
('AC5460', 'VINAYAK TRIPATHI', '213/1', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AC5787', 'Namra Lalji Bangari', '203/15', '2', 0, 'D', true, NOW(), NOW()),                             +
('AC6389', 'GAJULA SRISHANTH', '103/4', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AC6825', 'MATPATHI PRATHAM ADITYA', '212/6', '2', 0, 'D', true, NOW(), NOW()),                          +
('AC7228', 'GULLA SHIVA KUMAR', '110/12', '1', 0, 'D', true, NOW(), NOW()),                               +
('AC7573', 'Shivam Shinde', '114/4', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AC8429', 'Sabavath Suresh', '306/13', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AC8713', 'JAY PATEL', '111/15', '1', 0, 'D', true, NOW(), NOW()),                                       +
('AC9852', 'KOUSHIK BONKURI', '204/15', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AD1185', 'shiven lahoti', '213/10', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AD1194', 'Gosula Deekshith', '208/2', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AD1725', 'MAHATHO DAAMAN RAJ', '112/1', '1', 0, 'D', true, NOW(), NOW()),                               +
('AD2038', 'PINNINTI UDAY HARSHA', '108/1', '1', 0, 'D', true, NOW(), NOW()),                             +
('AD2125', 'SAATHVIK BONAKURTHI', '209/10', '2', 0, 'D', true, NOW(), NOW()),                             +
('AD2140', 'KOTA SAI AARUSH', '110/15', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AD2257', 'JAPA SHASHANK REDDY', '105/4', '1', 0, 'D', true, NOW(), NOW()),                              +
('AD2352', 'BHASWRAJU VIVEK', '101/3', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AD2478', 'KOTA DHANUSH', '214/7', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AD2684', 'P SHREEHAAN TEZ', '205/5', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AD2965', 'GOTTIMUKKULA RISHAB RAO', '112/13', '1', 0, 'D', true, NOW(), NOW()),                         +
('AD3058', 'RAJVEER SHINDE', '112/8', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AD3061', 'CHINTAPUDI JAYASIMHA', '202/10', '2', 0, 'D', true, NOW(), NOW()),                            +
('AD3355', 'Uppala Sai Chandra', '102/14', '1', 0, 'D', true, NOW(), NOW()),                              +
('AD3446', 'Jai Lodha', '207/3', '2', 0, 'D', true, NOW(), NOW()),                                        +
('AD4108', 'Soppari Ram Charan', '111/7', '1', 0, 'D', true, NOW(), NOW()),                               +
('AD4265', 'V SAI KOUSHIK', '202/13', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AD4397', 'VAIBHAVRAJ SINGH BHATI', '204/2', '2', 0, 'D', true, NOW(), NOW()),                           +
('AD4481', 'PEDDINTI MANI SHANKAR', '106/12', '1', 0, 'D', true, NOW(), NOW()),                           +
('AD4516', 'Omkar Swarup Pradhan', '101/10', '1', 0, 'D', true, NOW(), NOW()),                            +
('AD4560', 'ABHIRAM AVVARU', '201/12', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AD4896', 'AKASH MITTAL', '109/4', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AD4924', 'Dodda Sri Sai Prateek Kumar', '110/2', '1', 0, 'D', true, NOW(), NOW()),                      +
('AD5026', 'MAYANK HARSHAD PATEL', '201/9', '2', 0, 'D', true, NOW(), NOW()),                             +
('AD5037', 'YERRA MOHAN KARTHIKEYA', '101/7', '1', 0, 'D', true, NOW(), NOW()),                           +
('AD5064', 'PABBA SATHVIK', '101/6', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AD5180', 'SANGANI HARSHIT RAKESHBHAI', '109/3', '1', 0, 'D', true, NOW(), NOW()),                       +
('AD5194', 'Sparsh Laxmi Narayan Mandhani', '202/3', '2', 0, 'D', true, NOW(), NOW()),                    +
('AD5270', 'BOLLARAM ANISH REDDY', '310/6', '3', 0, 'D', true, NOW(), NOW()),                             +
('AD5322', 'VAMSHI PRADHAN', '206/14', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AD5441', 'VEERANNAGARI VISHWATEJA REDDY', '111/13', '1', 0, 'D', true, NOW(), NOW()),                   +
('AD5550', 'Doma varshith Reddy', '207/2', '2', 0, 'D', true, NOW(), NOW()),                              +
('AD5627', 'BEJJARAPU VIDYADEEP', '204/4', '2', 0, 'D', true, NOW(), NOW()),                              +
('AD5701', 'DODDELA PRANAY RAJ', '104/1', '1', 0, 'D', true, NOW(), NOW()),                               +
('AD5738', 'OMKAR ARVIND CHAMLE', '114/1', '1', 0, 'D', true, NOW(), NOW()),                              +
('AD5878', 'AMGOTH ANKITH', '206/15', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AD5953', 'THOKALA REVANTH KAILASH', '209/4', '2', 0, 'D', true, NOW(), NOW()),                          +
('AD6299', 'GAJERA VED TUSHARBHAI', '311/16', '3', 0, 'D', true, NOW(), NOW()),                           +
('AD6316', 'RAUNAK VERMA', '109/5', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AD6640', 'DHARMAAVARAM GOWTHAMA NANDAN', '111/16', '1', 0, 'D', true, NOW(), NOW()),                    +
('AD6668', 'VYOM RANJIT AJRA', '208/9', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AD6669', 'Veer Singh Chouhan', '114/5', '1', 0, 'D', true, NOW(), NOW()),                               +
('AD6750', 'ATHARVA DUBEY', '108/8', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AD6794', 'DACHEPALLY SANJAY KARTHIKEYA', '113/6', '1', 0, 'D', true, NOW(), NOW()),                     +
('AD6942', 'JAPA DEEKSHITH REDDY', '214/10', '2', 0, 'D', true, NOW(), NOW()),                            +
('AD7021', 'PARIGE SOUMIK REDDY', '209/1', '2', 0, 'D', true, NOW(), NOW()),                              +
('AD7138', 'K YAGNESH', '204/7', '2', 0, 'D', true, NOW(), NOW()),                                        +
('AD7235', 'Yuvan Varma Jampana', '114/14', '1', 0, 'D', true, NOW(), NOW()),                             +
('AD7341', 'HRIDAY MUNDADA', '112/5', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AD7362', 'T SRISHANTH', '103/14', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AD7577', 'Singuluri Leela Pavan Kumar', '105/6', '1', 0, 'D', true, NOW(), NOW()),                      +
('AD7681', 'ABHIJIT BALAJI PADILE', '202/8', '2', 0, 'D', true, NOW(), NOW()),                            +
('AD7711', 'SAMUDRALA SRIRAM PRAHARSHA', '101/4', '1', 0, 'D', true, NOW(), NOW()),                       +
('AD7784', 'SAMRIDH SANDEEPKUMAR SINGH', '201/15', '2', 0, 'D', true, NOW(), NOW()),                      +
('AD7983', 'KANDADI SAKSHITH REDDY', '304/14', '3', 0, 'D', true, NOW(), NOW()),                          +
('AD8232', 'ASHUTOSH KUMAR', '205/15', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AD8237', 'U KEETHAN GOUD', '309/16', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AD8257', 'Aarush Jigneshkumar Kevadiya', '108/13', '1', 0, 'D', true, NOW(), NOW()),                    +
('AD8297', 'KOUSTUBH KULKARNI', '208/14', '2', 0, 'D', true, NOW(), NOW()),                               +
('AD8618', 'NAGELLI SHISHIR REDDY', '102/2', '1', 0, 'D', true, NOW(), NOW()),                            +
('AD8775', 'SABBANI ROHITH KUMAR', '104/9', '1', 0, 'D', true, NOW(), NOW()),                             +
('AD8786', 'SABBANI VARSHITH KUMAR', '307/10', '3', 0, 'D', true, NOW(), NOW()),                          +
('AD8823', 'VAIJNATH SHIVKANT MEDGE', '102/1', '1', 0, 'D', true, NOW(), NOW()),                          +
('AD8845', 'JISHAN GHOSH', '102/9', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AD8910', 'PALLE ADHARSH REDDY', '105/15', '1', 0, 'D', true, NOW(), NOW()),                             +
('AD8988', 'KAUKUTLA AVYUKTH REDDY', '114/7', '1', 0, 'D', true, NOW(), NOW()),                           +
('AD9100', 'AKSHAT SHAILENDRA TIWARI', '212/7', '2', 0, 'D', true, NOW(), NOW()),                         +
('AD9200', 'D.NARAYANA REDDY', '106/7', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AD9325', 'PULLA VISHWA CHAITANYA REDDY', '114/2', '1', 0, 'D', true, NOW(), NOW()),                     +
('AD9329', 'M NIVAS', '102/3', '1', 0, 'D', true, NOW(), NOW()),                                          +
('AD9480', 'AKSHAT SAO', '201/8', '2', 0, 'D', true, NOW(), NOW()),                                       +
('AD9505', 'LIKHESH BEVARA', '101/9', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AD9514', 'RUDRARAJU RISHITH', '204/10', '2', 0, 'D', true, NOW(), NOW()),                               +
('AD9524', 'AAKIREDDY AGASTYA RAO', '204/3', '2', 0, 'D', true, NOW(), NOW()),                            +
('AD9534', 'LAGGALA PRASANNA VADHAN', '305/8', '3', 0, 'D', true, NOW(), NOW()),                          +
('AD9571', 'POGAKU DIKSHIT KUMAR', '306/7', '3', 0, 'D', true, NOW(), NOW()),                             +
('AD9598', 'E MEGHANATH GOUD', '206/16', '2', 0, 'D', true, NOW(), NOW()),                                +
('AD9679', 'Kalidindi Akshay Sai Varma', '113/12', '1', 0, 'D', true, NOW(), NOW()),                      +
('AD9845', 'DHAIRYA PATEL', '104/13', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AD9852', 'SRI GANESH', '302/1', '3', 0, 'D', true, NOW(), NOW()),                                       +
('AE0283', 'N SRIVARDHAN REDDY', '114/10', '1', 0, 'D', true, NOW(), NOW()),                              +
('AE0518', 'NEELI SHEETHAL', '305/10', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AE0519', 'AYUSH MALPANI', '110/9', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AE0558', 'SHIVAM SANKHLA', '309/4', '3', 0, 'D', true, NOW(), NOW()),                                   +
('AE0570', 'VAGULDAS VARUN GOUD', '204/14', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE0577', 'CHIDRAPU RITHWIK', '214/11', '2', 0, 'D', true, NOW(), NOW()),                                +
('AE0588', 'PUSHKAR KUMBHAKAR', '202/16', '2', 0, 'D', true, NOW(), NOW()),                               +
('AE0605', 'HARSH PATEL', '112/4', '1', 0, 'D', true, NOW(), NOW()),                                      +
('AE0647', 'B MANISH', '102/12', '1', 0, 'D', true, NOW(), NOW()),                                        +
('AE0652', 'DURGAM VIJAYA SRIKAR', '111/5', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE0655', 'REVANTH GORU', '204/13', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AE0710', 'VIPUL CHOUDHARY', '112/2', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AE0745', 'BIKKUMALLA ANISH', '113/8', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AE0780', 'SUSHANT AMRUT VARNALE', '207/13', '2', 0, 'D', true, NOW(), NOW()),                           +
('AE0784', 'PRAVEEN CHOUDHARY', '112/11', '1', 0, 'D', true, NOW(), NOW()),                               +
('AE0792', 'TIGULLA ADITYA GOUD', '207/14', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE0808', 'CHINCHOLE GIRISH SACHIN', '112/10', '1', 0, 'D', true, NOW(), NOW()),                         +
('AE0845', 'LALITH PANIGRAHI GANGU', '112/9', '1', 0, 'D', true, NOW(), NOW()),                           +
('AE1015', 'M SANYUTH', '305/16', '3', 0, 'D', true, NOW(), NOW()),                                       +
('AE1033', 'Vansh Vishwanath Chitmalwar', '211/13', '2', 0, 'D', true, NOW(), NOW()),                     +
('AE1064', 'K BHUVAN', '109/9', '1', 0, 'D', true, NOW(), NOW()),                                         +
('AE1091', 'KANUKULA KARTHIK REDDY', '113/10', '1', 0, 'D', true, NOW(), NOW()),                          +
('AE1107', 'TAKLE SANSKAR DIGAMBAR', '302/12', '3', 0, 'D', true, NOW(), NOW()),                          +
('AE1175', 'SAKA VISHWATEJA', '203/8', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AE1176', 'ARSHANAPELLI JASHAN RAO', '103/7', '1', 0, 'D', true, NOW(), NOW()),                          +
('AE1222', 'RUDRESH ARUN ASHTURE', '108/16', '1', 0, 'D', true, NOW(), NOW()),                            +
('AE1364', 'YELUGULA GURU CHARAN', '214/12', '2', 0, 'D', true, NOW(), NOW()),                            +
('AE1390', 'KUTHURU SRI SAI RITHIK', '203/5', '2', 0, 'D', true, NOW(), NOW()),                           +
('AE1489', 'PARTH PIYUSH PATEL', '107/10', '1', 0, 'D', true, NOW(), NOW()),                              +
('AE1619', 'MOPURU REVANTH REDDY', '106/4', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE1802', 'HARSH KHEDEKAR', '113/11', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AE1860', 'SUNKARI JAYANTH', '304/1', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AE1879', 'AKULA GEETH VARUN', '105/2', '1', 0, 'D', true, NOW(), NOW()),                                +
('AE2110', 'DIWAN SURYA SHREYAS', '107/3', '1', 0, 'D', true, NOW(), NOW()),                              +
('AE2190', 'N ADVITH', '310/10', '3', 0, 'D', true, NOW(), NOW()),                                        +
('AE2250', 'KILARI.VENKATA SAI HARSHA', '109/2', '1', 0, 'D', true, NOW(), NOW()),                        +
('AE2354', 'BHUVANESHWAR POLICE PATEL', '108/10', '1', 0, 'D', true, NOW(), NOW()),                       +
('AE2358', 'GOURAV SINGH', '107/12', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AE2389', 'VEERAMALLA DHEERAJ', '101/1', '1', 0, 'D', true, NOW(), NOW()),                               +
('AE2449', 'HARSH PATEL', '111/1', '1', 0, 'D', true, NOW(), NOW()),                                      +
('AE2502', 'BATHINA BHARATH MANIKANTA', '112/12', '1', 0, 'D', true, NOW(), NOW()),                       +
('AE2503', 'MURTHY TEJASWI MUMMIDAVARAPU', '102/7', '1', 0, 'D', true, NOW(), NOW()),                     +
('AE2644', 'MONTHA SAHAS CHANDRA', '205/13', '2', 0, 'D', true, NOW(), NOW()),                            +
('AE2656', 'ANNU SRI CHARAN REDDY', '214/1', '2', 0, 'D', true, NOW(), NOW()),                            +
('AE2752', 'KOTHAPALLY PRANEETH REDDY', '108/9', '1', 0, 'D', true, NOW(), NOW()),                        +
('AE2952', 'A MANIVARDHAN REDDY', '214/16', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE2973', 'V JASWANTH SRI MANIKANTA', '106/9', '1', 0, 'D', true, NOW(), NOW()),                         +
('AE3131', 'LOVE KUMAR SINHA', '201/4', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AE3270', '.GANNAVARAPU JOGEESWAR', '305/2', '3', 0, 'D', true, NOW(), NOW()),                           +
('AE3504', 'KANNAIAHGARI MANISH', '201/3', '2', 0, 'D', true, NOW(), NOW()),                              +
('AE3590', 'JUPALLY REVANTH RAO', '203/13', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE3856', 'DUBBAKA SHIVA CHARAN', '203/4', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE4023', 'YEMSANI SAIAKSHITH YADAV', '205/10', '2', 0, 'D', true, NOW(), NOW()),                        +
('AE4026', 'Prathemesh Kedareshwar Chitmalwar', '111/8', '1', 0, 'D', true, NOW(), NOW()),                +
('AE4186', 'FALDU LAKSH KISHOR KUMAR', '112/7', '1', 0, 'D', true, NOW(), NOW()),                         +
('AE4269', 'KAVALI SAIRAM', '202/6', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AE4400', 'BANTU BHANSHIDHAR', '305/6', '3', 0, 'D', true, NOW(), NOW()),                                +
('AE4551', 'RNS PURUSHOTTAM', '109/8', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AE4568', 'CHOLKAR PRAVASTHIK', '304/3', '3', 0, 'D', true, NOW(), NOW()),                               +
('AE4571', 'YEMSANI RAM VARSHITH YADAV', '301/6', '3', 0, 'D', true, NOW(), NOW()),                       +
('AE4751', 'RATHLA VIVEK', '110/3', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AE4774', 'Dhrumil P Sanchaniya', '113/3', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE4784', 'G CHANDRESH PATEL', '102/5', '1', 0, 'D', true, NOW(), NOW()),                                +
('AE4808', 'KODIGANTI KARTHIK', '103/8', '1', 0, 'D', true, NOW(), NOW()),                                +
('AE4809', 'SANDEEP PATEL', '303/6', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AE4812', 'Taaran Vijay Zalavadiya', '311/10', '3', 0, 'D', true, NOW(), NOW()),                         +
('AE4819', 'METHRE SATISH', '210/3', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AE4833', 'CHAMINETI MANI KANTA', '208/1', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE4851', 'VUPPARI SAI MANI DATHU', '204/5', '2', 0, 'D', true, NOW(), NOW()),                           +
('AE4852', 'DASARI VARSHITH', '308/15', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AE4855', 'YARRAM SRUJANNADH REDDY', '305/11', '3', 0, 'D', true, NOW(), NOW()),                         +
('AE4890', 'AYUSH NEMANI', '111/2', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AE4906', 'MADDURI SAMPATH', '306/1', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AE4937', 'CHETAN MUDUNURI', '305/9', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AE4941', 'PANAV GUPTA', '110/1', '1', 0, 'D', true, NOW(), NOW()),                                      +
('AE4945', 'SMARAN JASTI', '101/5', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AE4946', 'SAMITH JASTI', '206/8', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AE4950', 'PARTH PATEL', '305/15', '3', 0, 'D', true, NOW(), NOW()),                                     +
('AE4958', 'ADVIK PAMMI', '311/1', '3', 0, 'D', true, NOW(), NOW()),                                      +
('AE4959', 'V RAM CHARAN', '202/2', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AE5021', 'Thannir Harsha Vardhan', '307/16', '3', 0, 'D', true, NOW(), NOW()),                          +
('AE5022', 'T Harish', '306/11', '3', 0, 'D', true, NOW(), NOW()),                                        +
('AE5050', 'ADARSH TIWARY', '301/9', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AE5087', 'BIRADAR NIHAL CHANDRA', '209/7', '2', 0, 'D', true, NOW(), NOW()),                            +
('AE5112', 'SACHIN KUMAR', '104/10', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AE5138', 'HRUDAY PATEL', '306/15', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AE5149', 'HRUDAY SAI SRUNGAVARAPU', '212/4', '2', 0, 'D', true, NOW(), NOW()),                          +
('AE5220', 'B HARSHAVARDHAN', '309/11', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AE5283', 'B NITHISH YADAV', '309/13', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AE5284', 'MANDADI PRATEEK REDDY', '203/2', '2', 0, 'D', true, NOW(), NOW()),                            +
('AE5290', 'BANDARI RITHVIK', '309/2', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AE5304', 'ANMOL ANIL JAJU', '308/4', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AE5358', 'Y JOGENDRA', '207/9', '2', 0, 'D', true, NOW(), NOW()),                                       +
('AE5456', 'GADDE KARTEEK CHOWDARY', '306/16', '3', 0, 'D', true, NOW(), NOW()),                          +
('AE5504', 'ANURAG SINGH', '105/13', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AE5578', 'LOKINENI SATWIK RAO', '301/13', '3', 0, 'D', true, NOW(), NOW()),                             +
('AE5672', 'BADDAM AVINASH REDDY', '304/6', '3', 0, 'D', true, NOW(), NOW()),                             +
('AE5673', 'RUCHIK KUMAR PATEL', '304/13', '3', 0, 'D', true, NOW(), NOW()),                              +
('AE5696', 'ALLURI NAGA SAI SIDDARDHA VARMA', '204/12', '2', 0, 'D', true, NOW(), NOW()),                 +
('AE5713', 'VATTIPROLU SIVA SAI PAVAN KRISHNA', '112/14', '1', 0, 'D', true, NOW(), NOW()),               +
('AE5727', 'PANDURI SOMA MRUDUL', '109/13', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE5738', 'SOHITH SUBHANG RISHI VATTURI', '101/2', '1', 0, 'D', true, NOW(), NOW()),                     +
('AE5742', 'LEKH JAYESH PATEL', '111/10', '1', 0, 'D', true, NOW(), NOW()),                               +
('AE5743', 'DARSH JITENDRA PATEL', '110/5', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE5755', 'ARADLA ABHINAV REDDY', '109/12', '1', 0, 'D', true, NOW(), NOW()),                            +
('AE5756', 'HARIVANSH SANKLA', '114/9', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AE5771', 'JENIL P VADALIYA', '111/14', '1', 0, 'D', true, NOW(), NOW()),                                +
('AE5774', 'PENMETSA AMAN VARMA', '106/8', '1', 0, 'D', true, NOW(), NOW()),                              +
('AE5783', 'ISHAAN MUTHYALA', '104/8', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AE5788', 'G LOHITH REDDY', '109/7', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AE5810', 'BANOTH VIVEK VARSHITH', '105/9', '1', 0, 'D', true, NOW(), NOW()),                            +
('AE5861', 'TELLAKULA PURNA NANDAN', '114/12', '1', 0, 'D', true, NOW(), NOW()),                          +
('AE5906', 'DHARMA MUKESH SAVALIA', '108/5', '1', 0, 'D', true, NOW(), NOW()),                            +
('AE5946', 'DONDI HARSHITH', '107/6', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AE6008', 'AKHILESH VISHAL BANGAD', '112/6', '1', 0, 'D', true, NOW(), NOW()),                           +
('AE6032', 'BONTHA LOHITHESH', '114/11', '1', 0, 'D', true, NOW(), NOW()),                                +
('AE6039', 'ARNAV AJAY KULKARNI', '303/5', '3', 0, 'D', true, NOW(), NOW()),                              +
('AE6043', 'SWAYAM MOHTA', '110/10', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AE6192', 'VADLA SHREE HARI', '103/5', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AE6225', 'KARRI YASHWANTH SATHYA VENKATA SAI', '103/16', '1', 0, 'D', true, NOW(), NOW()),              +
('AE6228', 'CHINTHA KUSHAL KUMAR REDDY', '309/15', '3', 0, 'D', true, NOW(), NOW()),                      +
('AE6272', 'BHUWAN MANGESH MUNDADA', '203/3', '2', 0, 'D', true, NOW(), NOW()),                           +
('AE6337', 'AMGOTH REVANTH', '106/13', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AE6341', 'YASH GUNDAPPA KANTE', '307/11', '3', 0, 'D', true, NOW(), NOW()),                             +
('AE6342', 'RUDRA KALAPP MALBHAGE', '304/16', '3', 0, 'D', true, NOW(), NOW()),                           +
('AE6343', 'METTU TRILOK REDDY', '201/10', '2', 0, 'D', true, NOW(), NOW()),                              +
('AE6350', 'POSHAL KARUNYA', '103/3', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AE6358', 'BADRI VARSHITH PATEL', '106/16', '1', 0, 'D', true, NOW(), NOW()),                            +
('AE6369', 'MANTHRI VINAYAK', '110/7', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AE6387', 'CH SHIVA KESHAVA', '111/4', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AE6389', 'NELAPATI SHARATH CHANDRA', '209/13', '2', 0, 'D', true, NOW(), NOW()),                        +
('AE6537', 'KOTA SANJEEVA HIMESH', '113/2', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE6541', 'Boda Surya Jathin', '201/6', '2', 0, 'D', true, NOW(), NOW()),                                +
('AE6546', 'TESHI PARESH THOTA', '209/11', '2', 0, 'D', true, NOW(), NOW()),                              +
('AE6895', 'Tagalpallewak Arya Prajwal', '301/4', '3', 0, 'D', true, NOW(), NOW()),                       +
('AE7065', 'Bhaliya Het Vipulbhai', '201/13', '2', 0, 'D', true, NOW(), NOW()),                           +
('AE7078', 'V CHAITANYA SWARWOOP', '101/8', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE7275', 'MYADAM AKSHAY', '203/9', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AE7350', 'DONTHA SUPRATHIK', '207/15', '2', 0, 'D', true, NOW(), NOW()),                                +
('AE7503', 'GAURAV SUDHIR CHIRWATKAR', '212/2', '2', 0, 'D', true, NOW(), NOW()),                         +
('AE7584', 'K LAXMI PRANEETH', '306/2', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AE7588', 'PRITAM DHIRAJ MEHTA', '205/3', '2', 0, 'D', true, NOW(), NOW()),                              +
('AE7917', 'NALLA SRUJAN REDDY', '214/9', '2', 0, 'D', true, NOW(), NOW()),                               +
('AE8014', 'JAISWAL PREET', '207/6', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AE8029', 'SNEHIT BHATPALLIWAR', '203/14', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE8083', 'SARTHAK SAGAR ZANWAR', '309/1', '3', 0, 'D', true, NOW(), NOW()),                             +
('AE8150', 'KUMMATI DEEPAK REDDY', '107/5', '1', 0, 'D', true, NOW(), NOW()),                             +
('AE8255', 'Bhanderi Preet Rameshbhai', '110/6', '1', 0, 'D', true, NOW(), NOW()),                        +
('AE8352', 'Gajjala Madhu Karthik', '211/3', '2', 0, 'D', true, NOW(), NOW()),                            +
('AE8360', 'GUMUDALA VARSHITH', '108/14', '1', 0, 'D', true, NOW(), NOW()),                               +
('AE8368', 'GUMMADI MANOJ REDDY', '302/15', '3', 0, 'D', true, NOW(), NOW()),                             +
('AE8407', 'RAGHAV PATEL', '103/13', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AE8422', 'NITYA PATEL', '104/6', '1', 0, 'D', true, NOW(), NOW()),                                      +
('AE8491', 'SAMARTH PARIMAL BEDRE', '205/9', '2', 0, 'D', true, NOW(), NOW()),                            +
('AE8551', 'RAMA JEEVAN', '203/10', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AE8559', 'PARTH MANOJ BHANUSHALI', '210/7', '2', 0, 'D', true, NOW(), NOW()),                           +
('AE8783', 'ADITYA KHATRI', '113/9', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AE8858', 'JAISWAL SURAJ RAKESH', '209/8', '2', 0, 'D', true, NOW(), NOW()),                             +
('AE8919', 'ADITYA POONDRU', '109/14', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AE8928', 'PREM KUMAR PATIL', '108/2', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AE8938', 'SOMAVARAPU RUTHVIK', '204/6', '2', 0, 'D', true, NOW(), NOW()),                               +
('AE8986', 'Thakur RAGHUVENDR SINGH', '301/12', '3', 0, 'D', true, NOW(), NOW()),                         +
('AE9000', 'PETHANI HET SHAILESHBHAI', '109/10', '1', 0, 'D', true, NOW(), NOW()),                        +
('AE9100', 'G. PIYUSH REDDY', '206/6', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AE9143', 'PHANI NAGA SAI RITHVIK REDDY T', '303/16', '3', 0, 'D', true, NOW(), NOW()),                  +
('AE9179', 'KOUSHIK S', '103/2', '1', 0, 'D', true, NOW(), NOW()),                                        +
('AE9260', 'NAKUL SINGH RAJ PUROHIT', '205/12', '2', 0, 'D', true, NOW(), NOW()),                         +
('AE9278', 'PATOLLA SRI HARSHITH REDDY', '304/9', '3', 0, 'D', true, NOW(), NOW()),                       +
('AE9351', 'SHANIGIRAM HARSHA VARDHAN', '206/2', '2', 0, 'D', true, NOW(), NOW()),                        +
('AE9514', 'MADDURI NIHITH JAI VENKATA SAI', '303/1', '3', 0, 'D', true, NOW(), NOW()),                   +
('AE9555', 'SRI VASTHAVA G', '307/7', '3', 0, 'D', true, NOW(), NOW()),                                   +
('AE9556', 'NAVADEEP G', '307/8', '3', 0, 'D', true, NOW(), NOW()),                                       +
('AE9604', 'RAM SINGH', '205/6', '2', 0, 'D', true, NOW(), NOW()),                                        +
('AE9621', 'KERELLI YASHWANTH REDDY', '208/13', '2', 0, 'D', true, NOW(), NOW()),                         +
('AE9623', 'NILAY AMIT LANDGE', '108/15', '1', 0, 'D', true, NOW(), NOW()),                               +
('AE9670', 'DASARI SAI TEJA', '208/10', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AE9724', 'ILA SHRITHAN', '106/1', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AE9742', 'DEVKRUSHNA PRAVINKUMAR TIMBADIYA', '203/16', '2', 0, 'D', true, NOW(), NOW()),                +
('AE9787', 'ACHAN VARSHITH', '212/13', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AE9867', 'KUNCHARAM VAIBHAV', '214/13', '2', 0, 'D', true, NOW(), NOW()),                               +
('AE9881', 'VENKATAPURAM REVANTH GOUD', '208/3', '2', 0, 'D', true, NOW(), NOW()),                        +
('AF0903', 'MASINA JAYASURYA', '207/5', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AF1080', 'DASHRATH SINGH', '114/6', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AF1162', 'V B DHRUVAKETHAN REDDY', '205/2', '2', 0, 'D', true, NOW(), NOW()),                           +
('AF1254', 'PARTH PATEL', '209/16', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AF1274', 'KOLIPAKA RUSHI RUTHVIK', '305/13', '3', 0, 'D', true, NOW(), NOW()),                          +
('AF1539', 'MUKUL MALPANI', '108/3', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AF1627', 'SHUBHAM JOSHI', '302/3', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AF1688', 'GUDA VASTALYA VISHNU VARDHAN REDDY', '106/2', '1', 0, 'D', true, NOW(), NOW()),               +
('AF1954', 'LAVUDYA SATHVIK', '302/2', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AF2002', 'SONTI REDDY PRITAM REDDY', '106/6', '1', 0, 'D', true, NOW(), NOW()),                         +
('AF2193', 'VARTHYA MAHENDHAR', '301/14', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF2303', 'CHARABUDDI NEHANTH REDDY', '105/5', '1', 0, 'D', true, NOW(), NOW()),                         +
('AF2326', 'RYAKALA BHAVESH GOUD', '307/13', '3', 0, 'D', true, NOW(), NOW()),                            +
('AF2338', 'PALAVALASA ADITHYA VARDHAN', '308/11', '3', 0, 'D', true, NOW(), NOW()),                      +
('AF2351', 'S MANOCHARAN', '103/1', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AF2356', 'KAVISH SHAILESH CHITMALWAR', '310/15', '3', 0, 'D', true, NOW(), NOW()),                      +
('AF2359', 'N SAI KARTHIK', '311/12', '3', 0, 'D', true, NOW(), NOW()),                                   +
('AF2447', 'KONDA ABHI RAM', '106/15', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF2450', 'NYATHKALA KARTHIKEYA', '104/12', '1', 0, 'D', true, NOW(), NOW()),                            +
('AF2467', 'VIHAAN GAGGARA', '213/14', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF2492', 'GUNDAGANI HRISHITH', '105/14', '1', 0, 'D', true, NOW(), NOW()),                              +
('AF2605', 'RANGAN MANDAL', '208/11', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AF2695', 'VIPPAKAYALA KAVISH', '112/3', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF2716', 'G AADARSH', '305/1', '3', 0, 'D', true, NOW(), NOW()),                                        +
('AF2739', 'SAFFADI SUHAS', '203/1', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AF2748', 'PRATHMESH SANKHALA', '306/9', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF2756', 'GUDURI ABHINAV VARMA', '114/3', '1', 0, 'D', true, NOW(), NOW()),                             +
('AF2777', 'KAVYA NANJI VAID', '308/6', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AF2799', 'DESU YOJITH KUMAR', '306/4', '3', 0, 'D', true, NOW(), NOW()),                                +
('AF2804', 'RUDRA PEGAD', '202/15', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AF2851', 'SAINATH DHANAJI KOTALAPURE', '302/13', '3', 0, 'D', true, NOW(), NOW()),                      +
('AF2877', 'BHEEMANGARI DINESH REDDY', '103/15', '1', 0, 'D', true, NOW(), NOW()),                        +
('AF2878', 'GOLLAPALLY RUTHVIK GOUD', '305/4', '3', 0, 'D', true, NOW(), NOW()),                          +
('AF2917', 'Dhairya B Vavia', '206/9', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF2946', 'CHALASANI NIHANT CHOWDARY', '302/9', '3', 0, 'D', true, NOW(), NOW()),                        +
('AF2947', 'B Ashrith Sai Goud', '312/8', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF2955', 'SURUKUNTA SHRITHAN REDDY', '107/7', '1', 0, 'D', true, NOW(), NOW()),                         +
('AF2956', 'AMAND YATIN', '107/1', '1', 0, 'D', true, NOW(), NOW()),                                      +
('AF2970', 'THARUN SUDHAKAR', '113/13', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AF2980', 'GAURAV HANUMANTHKARI MARATHA', '111/12', '1', 0, 'D', true, NOW(), NOW()),                    +
('AF2981', 'P MADHAN KUMAR', '103/12', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF2987', 'NAGA UMAA BHARATCHAND TALLURI', '213/13', '2', 0, 'D', true, NOW(), NOW()),                   +
('AF3003', 'Kottu Hrusheekesha', '107/4', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF3017', 'AKULA HARSHA', '101/13', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AF3019', 'Khunt Dev', '103/9', '1', 0, 'D', true, NOW(), NOW()),                                        +
('AF3022', 'Diksh Devda', '106/10', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AF3023', 'Dhrith Devda', '210/14', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AF3037', 'HARDIK JAIN', '308/12', '3', 0, 'D', true, NOW(), NOW()),                                     +
('AF3078', 'SAI SATVIK BORULE', '108/11', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF3091', 'BIKSHAMAIAH PODILA', '107/9', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF3092', 'KASANAGOTTU AASHISH', '105/12', '1', 0, 'D', true, NOW(), NOW()),                             +
('AF3093', 'KAMUNI MANAS SHARWA PRASAD', '201/11', '2', 0, 'D', true, NOW(), NOW()),                      +
('AF3132', 'KRISHNA KUMAR AGARWAL', '205/16', '2', 0, 'D', true, NOW(), NOW()),                           +
('AF3154', 'S VIDHYACHARAN REDDY', '207/16', '2', 0, 'D', true, NOW(), NOW()),                            +
('AF3160', 'YOHAAN JAISWAL', '104/11', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF3258', 'Pottipally Rushil Reddy', '105/10', '1', 0, 'D', true, NOW(), NOW()),                         +
('AF3261', 'TERALA ABHIRAM', '203/12', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF3291', 'DONTHI VENKATA SATHYA TEJA', '305/5', '3', 0, 'D', true, NOW(), NOW()),                       +
('AF3321', 'BEDUDHURU THAXILESWARA REDDY', '107/14', '1', 0, 'D', true, NOW(), NOW()),                    +
('AF3338', 'Lolam ganesh', '102/10', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AF3385', 'KONDIKANTI NANI SAGAR', '104/15', '1', 0, 'D', true, NOW(), NOW()),                           +
('AF3391', 'KUDUPUDI JAIRAJ DHEER', '212/11', '2', 0, 'D', true, NOW(), NOW()),                           +
('AF3392', 'KUDUPUDI JAIRAJ VEER', '212/9', '2', 0, 'D', true, NOW(), NOW()),                             +
('AF3407', 'AMRITANSH AGARWAL', '310/1', '3', 0, 'D', true, NOW(), NOW()),                                +
('AF3434', 'CHHAVI RAJ', '312/5', '3', 0, 'D', true, NOW(), NOW()),                                       +
('AF3460', 'Ramagiri Sravan Bhargav', '107/8', '1', 0, 'D', true, NOW(), NOW()),                          +
('AF3585', 'Akshar kolnati', '209/14', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF3593', 'ADITYA AMOL AHER', '207/8', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AF3615', 'AARADHY RAJARAM PATIL', '302/4', '3', 0, 'D', true, NOW(), NOW()),                            +
('AF3618', 'VENDI EEKSHITH', '101/15', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF3631', 'AMITH ARJUNE', '104/14', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AF3639', 'BHAKHAR YUG RAMJIBHAI', '209/15', '2', 0, 'D', true, NOW(), NOW()),                           +
('AF3709', 'K RAM CHARAN UTTEJ', '101/12', '1', 0, 'D', true, NOW(), NOW()),                              +
('AF3711', 'KANKANALA SRI VIGNESH', '307/15', '3', 0, 'D', true, NOW(), NOW()),                           +
('AF3728', 'KOMMINENI S V L JHASAKETHAN', '206/12', '2', 0, 'D', true, NOW(), NOW()),                     +
('AF3732', 'CHITTI GIDDA SRI NANDHAN REDDY', '304/15', '3', 0, 'D', true, NOW(), NOW()),                  +
('AF3735', 'CHEETI SAI SUHAAS', '301/16', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF3798', 'SHOURYA AGARWAL', '104/5', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF3810', 'TIRTH KUMAR PATEL', '109/6', '1', 0, 'D', true, NOW(), NOW()),                                +
('AF3831', 'KOLAGANI MANIKANTHA', '106/11', '1', 0, 'D', true, NOW(), NOW()),                             +
('AF3836', 'KADAVERU HARI SHANKAR', '211/1', '2', 0, 'D', true, NOW(), NOW()),                            +
('AF3847', 'Y TRILOK GOUD', '111/6', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AF3924', 'NIKHIL BAJORIA', '210/13', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF3980', 'DIVYESH MUNDRA', '113/4', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AF3990', 'PASUPULETI HANISH KARTHIKEYA', '210/1', '2', 0, 'D', true, NOW(), NOW()),                     +
('AF4007', 'SHESHAVPURI TANISHQ', '102/8', '1', 0, 'D', true, NOW(), NOW()),                              +
('AF4039', 'ADITHYA SRINIVAS NAIDU TIRUMALASETTY', '102/6', '1', 0, 'D', true, NOW(), NOW()),             +
('AF4062', 'VADDEPU SANJITH', '311/11', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AF4106', 'VISHNU', '201/5', '2', 0, 'D', true, NOW(), NOW()),                                           +
('AF4156', 'HIMANSHU BAJAJ', '213/9', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AF4167', 'BANOTU NITEESH KUMAR', '111/9', '1', 0, 'D', true, NOW(), NOW()),                             +
('AF4197', 'HARSHIT PATEL', '114/16', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AF4203', 'ALLAM ROHITH KUMAR REDDY', '106/14', '1', 0, 'D', true, NOW(), NOW()),                        +
('AF4216', 'KRITANU ANAND', '106/3', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AF4220', 'HARSHIL TAPARIA', '207/10', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AF4222', 'DIVY MILANKUMAR', '311/5', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AF4235', 'SHERI NISHKESH REDDY', '201/2', '2', 0, 'D', true, NOW(), NOW()),                             +
('AF4246', 'NEERATI SRI AVYUKT', '303/2', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF4302', 'BANKI JAYA SHANKAR', '201/16', '2', 0, 'D', true, NOW(), NOW()),                              +
('AF4304', 'KOKKALAKONDA SHIVA SREEKAR', '105/7', '1', 0, 'D', true, NOW(), NOW()),                       +
('AF4379', 'REKULAPALLI MANIDEEP REDDY', '204/9', '2', 0, 'D', true, NOW(), NOW()),                       +
('AF4423', 'BUREWAR ARNAV RAJARAM', '304/2', '3', 0, 'D', true, NOW(), NOW()),                            +
('AF4498', 'BOBLAD SAKETH SHARMA', '211/7', '2', 0, 'D', true, NOW(), NOW()),                             +
('AF4499', 'ASHWATH KATAKAM', '103/10', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AF4502', 'ALLURI SHARATH CHANDRA', '108/12', '1', 0, 'D', true, NOW(), NOW()),                          +
('AF4509', 'THANIPARTHI KINSHUK', '202/5', '2', 0, 'D', true, NOW(), NOW()),                              +
('AF4524', 'NIGEL WANGKHEIMAYUM', '102/13', '1', 0, 'D', true, NOW(), NOW()),                             +
('AF4598', 'GANJEWAR SRUJAN', '213/7', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF4632', 'M S RUDRAVEER', '310/5', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AF4640', 'HANDE VIGNESHWAR BALAJI', '206/3', '2', 0, 'D', true, NOW(), NOW()),                          +
('AF4645', 'SAKSHAM KUMAR JAISWAL', '204/1', '2', 0, 'D', true, NOW(), NOW()),                            +
('AF4706', 'INDUKURI UPENDRA VARMA', '203/6', '2', 0, 'D', true, NOW(), NOW()),                           +
('AF4727', 'P JEEVAN NAYAK', '105/1', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AF4738', 'VIRAT PARAG AILWAR', '301/2', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF4790', 'TOKALA RUSHEEK SAINATH REDDY', '208/15', '2', 0, 'D', true, NOW(), NOW()),                    +
('AF4802', 'PITTLA SHREE HARSHA', '310/16', '3', 0, 'D', true, NOW(), NOW()),                             +
('AF4803', 'THIRUKOVELA ADWAITH', '311/14', '3', 0, 'D', true, NOW(), NOW()),                             +
('AF4818', 'MADHIRE HANRITH', '101/11', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AF4824', 'INJAM YUGESH', '308/2', '3', 0, 'D', true, NOW(), NOW()),                                     +
('AF4830', 'SHRIYASH DATTATRAY GURME', '102/16', '1', 0, 'D', true, NOW(), NOW()),                        +
('AF4846', 'GUBBALA YASHWANTH SAI VENKAT', '114/8', '1', 0, 'D', true, NOW(), NOW()),                     +
('AF4849', 'KHETANI ANSH PARAG', '109/1', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF4853', 'PRATEEK PATRA', '309/6', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AF4918', 'JUVVADI BALAJI RAO', '207/1', '2', 0, 'D', true, NOW(), NOW()),                               +
('AF4919', 'RUDRA MANIDHAR', '109/16', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF4923', 'RENTIKOTA JANAKI RAM', '107/15', '1', 0, 'D', true, NOW(), NOW()),                            +
('AF4925', 'MADUGULA BHANU TEJA', '302/6', '3', 0, 'D', true, NOW(), NOW()),                              +
('AF4958', 'AYYAMOLLA ROSHAN', '303/9', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AF4966', 'GUDURU SAI VISHRUTH', '207/12', '2', 0, 'D', true, NOW(), NOW()),                             +
('AF4967', 'GADARLA LOKESH', '208/16', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF4983', 'VANGAPELLY SATHWIK RAO', '207/7', '2', 0, 'D', true, NOW(), NOW()),                           +
('AF4984', 'PALASH BHOWMIK', '104/16', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF4985', 'GUJJULA SHRIYAN REDDY', '110/16', '1', 0, 'D', true, NOW(), NOW()),                           +
('AF4992', 'ATMAKURI MANOHAR', '105/11', '1', 0, 'D', true, NOW(), NOW()),                                +
('AF5053', 'R TANUSH REDDY', '113/16', '1', 0, 'D', true, NOW(), NOW()),                                  +
('AF5055', 'MADASTU DAYANANDA', '301/11', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF5271', 'B CHETAN SWAROOP REDDY', '302/10', '3', 0, 'D', true, NOW(), NOW()),                          +
('AF5386', 'GOLLA SHISHIR YADAV', '211/14', '2', 0, 'D', true, NOW(), NOW()),                             +
('AF5426', 'Mahir Rajesh Kumar Vegad', '212/12', '2', 0, 'D', true, NOW(), NOW()),                        +
('AF5511', 'Malye Srujan', '214/14', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AF5536', 'VENNA JAYANTH REDDY', '308/9', '3', 0, 'D', true, NOW(), NOW()),                              +
('AF5547', 'PUJALA KARTHIK', '310/12', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AF5574', 'DAMANNAGARI SHOURYA DEEP REDDY', '106/5', '1', 0, 'D', true, NOW(), NOW()),                   +
('AF5582', 'PATLORI VAISHWIK REDDY', '301/1', '3', 0, 'D', true, NOW(), NOW()),                           +
('AF5618', 'AVIDI POORNA CHANDRA NAGA SAI', '208/8', '2', 0, 'D', true, NOW(), NOW()),                    +
('AF5628', 'RUTHVIK AYILA A', '212/16', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AF5779', 'CHAITANYA VENKATESH TAMBAT', '213/15', '2', 0, 'D', true, NOW(), NOW()),                      +
('AF5793', 'VEDANT PATEL', '113/7', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AF5873', 'Alakh Tiwari', '109/15', '1', 0, 'D', true, NOW(), NOW()),                                    +
('AF5878', 'MANCHUKONDA SAI AAKARSHAN', '309/9', '3', 0, 'D', true, NOW(), NOW()),                        +
('AF5886', 'VIRAT SINGH', '304/10', '3', 0, 'D', true, NOW(), NOW()),                                     +
('AF5903', 'THIRUPATHI VARUN REDDY', '310/2', '3', 0, 'D', true, NOW(), NOW()),                           +
('AF5926', 'ALUVALA SRI SHIVA SAHISHNU', '105/3', '1', 0, 'D', true, NOW(), NOW()),                       +
('AF5955', 'YASH SHAW', '110/11', '1', 0, 'D', true, NOW(), NOW()),                                       +
('AF6065', 'CHINTHAJINGA ASHWITH', '205/11', '2', 0, 'D', true, NOW(), NOW()),                            +
('AF6093', 'URVASH JAIN', '206/5', '2', 0, 'D', true, NOW(), NOW()),                                      +
('AF6150', 'GURRAM JAYANTH REDDY', '206/10', '2', 0, 'D', true, NOW(), NOW()),                            +
('AF6178', 'K VIBHAS', '101/14', '1', 0, 'D', true, NOW(), NOW()),                                        +
('AF6185', 'SAMA MUKESH GOUD', '206/7', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AF6244', 'KHUSHAL MUNDADA', '205/8', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF6261', 'ANDE SIDHARTH', '204/11', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AF6266', 'VAKITI RAGHUPATHI NARAYANA REDDY', '206/1', '2', 0, 'D', true, NOW(), NOW()),                 +
('AF6270', 'LOGUS BOTHRA', '202/9', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AF6271', 'SUYASH VAID', '111/11', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AF6272', 'PRANSHU BOTHRA', '201/1', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AF6328', 'DAMAM BHARATH', '102/15', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AF6342', 'THAKUR RUDHRA PRATHAP SINGH', '113/5', '1', 0, 'D', true, NOW(), NOW()),                      +
('AF6409', 'YUG PRAFUL BHAI AKBARI', '114/15', '1', 0, 'D', true, NOW(), NOW()),                          +
('AF6412', 'PEDAKOTA SHREEHANS', '108/7', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF6460', 'Moturi Vedavyasa', '206/11', '2', 0, 'D', true, NOW(), NOW()),                                +
('AF6467', 'RUPAPARA DIVY MILAN BHAI', '109/11', '1', 0, 'D', true, NOW(), NOW()),                        +
('AF6468', 'KHATRA RENISH MEHULBHAI', '110/4', '1', 0, 'D', true, NOW(), NOW()),                          +
('AF6469', 'PIPALIYA PARTH MAHESHBHAI', '113/1', '1', 0, 'D', true, NOW(), NOW()),                        +
('AF6482', 'ARYAN KUMAR', '112/15', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AF6518', 'MOHIT YOGESH KATHIRIA', '107/13', '1', 0, 'D', true, NOW(), NOW()),                           +
('AF6519', 'GONUGUNTLA ANISH CHOWDARY', '107/2', '1', 0, 'D', true, NOW(), NOW()),                        +
('AF6550', 'Hemansh Motwani', '112/16', '1', 0, 'D', true, NOW(), NOW()),                                 +
('AF6649', 'BADATHALA RUSHI', '303/13', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AF6695', 'ALOK YADAV', '310/4', '3', 0, 'D', true, NOW(), NOW()),                                       +
('AF6700', 'PALEPU NAVEEN RAJU', '102/4', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF6797', 'PRIYANK TAUNK', '113/15', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AF6940', 'RAWWARAPU CHAITANYA KARTHICK', '208/7', '2', 0, 'D', true, NOW(), NOW()),                     +
('AF7048', 'BUDDE ASHWITH VARMA', '312/7', '3', 0, 'D', true, NOW(), NOW()),                              +
('AF7056', 'BADKA BHAGATH', '301/7', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AF7113', 'DEVANI SHREY RAJESH BHAI', '110/14', '1', 0, 'D', true, NOW(), NOW()),                        +
('AF7140', 'GAJERA DHRUVKUMAR KRISHNAKANT', '107/11', '1', 0, 'D', true, NOW(), NOW()),                   +
('AF7217', 'BUYANA SAI SANNIHITH', '202/7', '2', 0, 'D', true, NOW(), NOW()),                             +
('AF7219', 'Avinash Dwivedi', '207/4', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF7228', 'YASH JAKAWAR', '311/13', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AF7229', 'SUMIT KUMAR', '311/8', '3', 0, 'D', true, NOW(), NOW()),                                      +
('AF7232', 'V ANIL', '312/2', '3', 0, 'D', true, NOW(), NOW()),                                           +
('AF7286', 'UJJWAL YASHPAL SOLANKI', '207/11', '2', 0, 'D', true, NOW(), NOW()),                          +
('AF7395', 'SRI SAI VIGNESH', '210/9', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF7485', 'K SHARVANTH', '303/7', '3', 0, 'D', true, NOW(), NOW()),                                      +
('AF7534', 'Akula dhanush', '105/16', '1', 0, 'D', true, NOW(), NOW()),                                   +
('AF7714', 'MANIKYAM ARYAN', '301/5', '3', 0, 'D', true, NOW(), NOW()),                                   +
('AF7791', 'VAIDAMBH SHARMA', '205/7', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF7855', 'SEETHAPATHI TANISH', '104/3', '1', 0, 'D', true, NOW(), NOW()),                               +
('AF7892', 'MALLEM SATYA VENKATA AGRATA', '306/3', '3', 0, 'D', true, NOW(), NOW()),                      +
('AF7958', 'SORATHIYA JEEL RAJESH', '211/2', '2', 0, 'D', true, NOW(), NOW()),                            +
('AF8134', 'N Harshan', '301/15', '3', 0, 'D', true, NOW(), NOW()),                                       +
('AF8299', 'AARSH', '303/4', '3', 0, 'D', true, NOW(), NOW()),                                            +
('AF8457', 'Shurya Suhas Chavan', '102/11', '1', 0, 'D', true, NOW(), NOW()),                             +
('AF8537', 'ACHYUTH RAO', '101/16', '1', 0, 'D', true, NOW(), NOW()),                                     +
('AF8553', 'VADALIYA DEV MITESHBHAI', '311/15', '3', 0, 'D', true, NOW(), NOW()),                         +
('AF8718', 'Magham Ruthwik', '213/16', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AF9101', 'JUKANTI CHAKRADAR GOUD', '210/4', '2', 0, 'D', true, NOW(), NOW()),                           +
('AF9185', 'P YAGNA SAI SHANKAR REDDY', '308/10', '3', 0, 'D', true, NOW(), NOW()),                       +
('AF9198', 'VISHRUTH BAIRAGONIWAR', '308/14', '3', 0, 'D', true, NOW(), NOW()),                           +
('AF9235', 'Harishankar Satvic', '209/3', '2', 0, 'D', true, NOW(), NOW()),                               +
('AF9236', 'Vadla karthikeya', '214/4', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AF9310', 'Sadhu Venkata Sai Aryan', '213/11', '2', 0, 'D', true, NOW(), NOW()),                         +
('AF9334', 'Vootukooru Veeranath Ruthvik', '307/5', '3', 0, 'D', true, NOW(), NOW()),                     +
('AF9360', 'MADI ASHWITH REDDY', '306/12', '3', 0, 'D', true, NOW(), NOW()),                              +
('AF9361', 'NAIKOTI MITHUN', '306/14', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AF9376', 'GURRAM SAI SANJEEV', '306/5', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF9381', 'P Ashwath Sai', '212/15', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AF9443', 'MEDURI SAI MARUTI MAHEDHAR', '305/12', '3', 0, 'D', true, NOW(), NOW()),                      +
('AF9464', 'MIRYALA SHRI CHARAN', '306/10', '3', 0, 'D', true, NOW(), NOW()),                             +
('AF9489', 'AMRITAM CHOUDHARY', '211/15', '2', 0, 'D', true, NOW(), NOW()),                               +
('AF9500', 'CHINTALAPATI HAVISH VARMA', '211/11', '2', 0, 'D', true, NOW(), NOW()),                       +
('AF9517', 'PARIKSHIT EKNATH CHINCHANE', '307/3', '3', 0, 'D', true, NOW(), NOW()),                       +
('AF9520', 'Laveti Devamsh Narayana', '305/14', '3', 0, 'D', true, NOW(), NOW()),                         +
('AF9522', 'CHEBOLU MAHALAKSHMI BAVESH SARMA', '302/5', '3', 0, 'D', true, NOW(), NOW()),                 +
('AF9526', 'BODE SIVAHARSHITH', '305/7', '3', 0, 'D', true, NOW(), NOW()),                                +
('AF9561', 'Biranchi Narayan Paramanik', '305/3', '3', 0, 'D', true, NOW(), NOW()),                       +
('AF9566', 'RAKHOLIYA RUDRA KISHORBHAI', '308/13', '3', 0, 'D', true, NOW(), NOW()),                      +
('AF9623', 'SIDDHARTH CHAWHAN', '304/12', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF9630', 'PODDUTURI SRIHAN', '212/3', '2', 0, 'D', true, NOW(), NOW()),                                 +
('AF9695', 'PIGILATI VISHNU VARDHAN', '304/7', '3', 0, 'D', true, NOW(), NOW()),                          +
('AF9703', 'ARPIT CHOURASIYA', '210/11', '2', 0, 'D', true, NOW(), NOW()),                                +
('AF9738', 'A SRIKAR', '304/5', '3', 0, 'D', true, NOW(), NOW()),                                         +
('AF9742', 'VITTAL SAI CHARAN', '311/6', '3', 0, 'D', true, NOW(), NOW()),                                +
('AF9769', 'KAMIDI PRANAV OMKAR REDDY', '210/15', '2', 0, 'D', true, NOW(), NOW()),                       +
('AF9850', 'SIDDAMSHETTY ADITYA', '303/12', '3', 0, 'D', true, NOW(), NOW()),                             +
('AF9883', 'RASHWA GAJANAN MUKKAWAR', '310/14', '3', 0, 'D', true, NOW(), NOW()),                         +
('AF9884', 'GURRALA MANISH REDDY', '303/11', '3', 0, 'D', true, NOW(), NOW()),                            +
('AF9885', 'KAVYA ASHOK PATEL', '310/13', '3', 0, 'D', true, NOW(), NOW()),                               +
('AF9886', 'Krishan Kumar', '303/14', '3', 0, 'D', true, NOW(), NOW()),                                   +
('AF9966', 'ELTAM VIJAY PRASAD', '209/9', '2', 0, 'D', true, NOW(), NOW()),                               +
('AF9994', 'Aradhy Shivkumar Bijamwar', '307/14', '3', 0, 'D', true, NOW(), NOW()),                       +
('AF9995', 'MOTHE SRIVATHSAV REDDY', '307/12', '3', 0, 'D', true, NOW(), NOW()),                          +
('AG0006', 'HARSHRAJ VIJAYRAJ JAMBHALE', '214/15', '2', 0, 'D', true, NOW(), NOW()),                      +
('AG0040', 'PUTTUBOINA CHARANJEET', '308/3', '3', 0, 'D', true, NOW(), NOW()),                            +
('AG0042', 'BHEEMANA TEJA SAI SIVA RAYA CHOWDARY', '308/5', '3', 0, 'D', true, NOW(), NOW()),             +
('AG0058', 'DEEPAN KUMAR SONI', '308/7', '3', 0, 'D', true, NOW(), NOW()),                                +
('AG0075', 'VEMURI MRITHULL', '312/1', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AG0079', 'PALLABOTULA SAI SRIYAAN', '209/5', '2', 0, 'D', true, NOW(), NOW()),                          +
('AG0080', 'CHIGURUPATI VASHISTA VARUN', '214/2', '2', 0, 'D', true, NOW(), NOW()),                       +
('AG0082', 'BURIGARI SIDDARTH MANI', '309/3', '3', 0, 'D', true, NOW(), NOW()),                           +
('AG0142', 'PRANAV GOVIND GHORPADE', '309/5', '3', 0, 'D', true, NOW(), NOW()),                           +
('AG0146', 'BELLAM KARTHIK', '309/7', '3', 0, 'D', true, NOW(), NOW()),                                   +
('AG0149', 'KOVVURI SHASHANK', '309/10', '3', 0, 'D', true, NOW(), NOW()),                                +
('AG0151', 'Surya Sagi', '210/5', '2', 0, 'D', true, NOW(), NOW()),                                       +
('AG0157', 'CHINTHAKUNTA VARSHITH REDDY', '309/12', '3', 0, 'D', true, NOW(), NOW()),                     +
('AG0184', 'KOTHAKAPU ABHIRAM REDDY', '213/12', '2', 0, 'D', true, NOW(), NOW()),                         +
('AG0219', 'AKSHAT TIWARI', '211/5', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AG0252', 'CHIKKELA SANKEERTH', '212/8', '2', 0, 'D', true, NOW(), NOW()),                               +
('AG0298', 'SAATVIK AKULA', '212/5', '2', 0, 'D', true, NOW(), NOW()),                                    +
('AG0299', 'Cigumal Bavyesh Kusal', '310/3', '3', 0, 'D', true, NOW(), NOW()),                            +
('AG0301', 'SRIPATHI MONISH VARDHAN', '213/3', '2', 0, 'D', true, NOW(), NOW()),                          +
('AG0322', 'SAURYAV SANDIP KADAM', '310/7', '3', 0, 'D', true, NOW(), NOW()),                             +
('AG0327', 'BALAN THARRUN JANAADHAN REDDY', '213/5', '2', 0, 'D', true, NOW(), NOW()),                    +
('AG0359', 'LINE SAI LOKESH', '311/7', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AG0393', 'NARNE AKHILESHWAR', '214/3', '2', 0, 'D', true, NOW(), NOW()),                                +
('AG0394', 'Pratyush prabhu', '310/11', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AG0405', 'CH VIJAY KUMAR', '311/2', '3', 0, 'D', true, NOW(), NOW()),                                   +
('AG0406', 'THOTA SAMANYU', '311/4', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AG0409', 'CHARAK BARAPATI', '213/6', '2', 0, 'D', true, NOW(), NOW()),                                  +
('AG0423', 'SOLI SUHAS', '307/1', '3', 0, 'D', true, NOW(), NOW()),                                       +
('AG0441', 'TEJAS SINGH', '212/10', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AG0454', 'RAVULA SHRIYAN REDDY', '311/9', '3', 0, 'D', true, NOW(), NOW()),                             +
('AG0474', 'SOMA ASHRITH REDDY', '312/4', '3', 0, 'D', true, NOW(), NOW()),                               +
('AG0554', 'UJJWAL RAJPUT', '312/6', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AG1123', 'POTHIREDDY PRADHAM REDDY', '302/11', '3', 0, 'D', true, NOW(), NOW()),                        +
('AG1154', 'POTLA VAMSHI KRISHNA', '303/15', '3', 0, 'D', true, NOW(), NOW()),                            +
('AG1177', 'Nevil D Thummar', '302/7', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AG1335', 'VARSHITH MONIGARI', '303/3', '3', 0, 'D', true, NOW(), NOW()),                                +
('AG1336', 'RAJAPURAM SAI CHARAN REDDY', '209/12', '2', 0, 'D', true, NOW(), NOW()),                      +
('AG1520', 'PRATHAMESH LAXMAN AILANE', '307/9', '3', 0, 'D', true, NOW(), NOW()),                         +
('AG1532', 'KATUKAM CHAITRANANDAM', '302/8', '3', 0, 'D', true, NOW(), NOW()),                            +
('AG1726', 'JUPALLY KRISHIK', '304/8', '3', 0, 'D', true, NOW(), NOW()),                                  +
('AG1797', 'ADITYA', '214/6', '2', 0, 'D', true, NOW(), NOW()),                                           +
('AG1833', 'RAMAGIRI AVANISH', '303/8', '3', 0, 'D', true, NOW(), NOW()),                                 +
('AG1858', 'PATHAPATI JAYANTH SATYA VARMA', '310/8', '3', 0, 'D', true, NOW(), NOW()),                    +
('AG1867', 'Abhinay Sai N', '308/8', '3', 0, 'D', true, NOW(), NOW()),                                    +
('AG1942', 'NIKUNJ ANAND BAJAJ', '306/8', '3', 0, 'D', true, NOW(), NOW()),                               +
('AG2159', 'BALGURI SRIKAR SAGAR', '309/8', '3', 0, 'D', true, NOW(), NOW()),                             +
('AG2698', 'BOKKA NIKHILESH REDDY', '210/12', '2', 0, 'D', true, NOW(), NOW()),                           +
('AG2711', 'Parepally Meher Rishikesh', '213/2', '2', 0, 'D', true, NOW(), NOW()),                        +
('AG2809', 'MANYAM TANUSH', '210/10', '2', 0, 'D', true, NOW(), NOW()),                                   +
('AG2839', 'KURAKULA SUSHANTH', '210/8', '2', 0, 'D', true, NOW(), NOW()),                                +
('AG2852', 'RISHI KUMAR', '210/6', '2', 0, 'D', true, NOW(), NOW()),                                      +
('AG2854', 'Vaishnav Devender', '211/9', '2', 0, 'D', true, NOW(), NOW()),                                +
('AG2868', 'KANNETI UDAY KUMAR', '210/2', '2', 0, 'D', true, NOW(), NOW()),                               +
('AG3040', 'RAMPALLY NIDHISH KARTIKEYA', '212/1', '2', 0, 'D', true, NOW(), NOW()),                       +
('AG3133', 'M Abhiraj', '311/3', '3', 0, 'D', true, NOW(), NOW()),                                        +
('AG3428', 'BURELA ABHIVARDHAN', '211/4', '2', 0, 'D', true, NOW(), NOW()),                               +
('AG3539', 'ANAND SWAMY', '211/6', '2', 0, 'D', true, NOW(), NOW()),                                      +
('AG3542', 'JADHAV SHANKAR RAJ', '211/8', '2', 0, 'D', true, NOW(), NOW()),                               +
('AG3811', 'NILESH SAHU', '211/10', '2', 0, 'D', true, NOW(), NOW()),                                     +
('AG3866', 'YUVRAJ SUDHIR DESHMUKH', '211/12', '2', 0, 'D', true, NOW(), NOW()),                          +
('AG4583', 'VASILI DAMARUKAM RISHI', '210/16', '2', 0, 'D', true, NOW(), NOW()),                          +
('AH0015', 'Rudra Pratap Nayak', '105/8', '1', 0, 'D', true, NOW(), NOW()),                               +
('AJ0027', 'VIVEK BILE', '202/4', '2', 0, 'D', true, NOW(), NOW());
(1 row)
