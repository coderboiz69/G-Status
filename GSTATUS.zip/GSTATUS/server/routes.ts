import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { updatePointsSchema } from "@shared/schema";
import { z } from "zod";

// Sample student data from the original HTML
const SAMPLE_STUDENTS = [
  { id: "AE2389", room: "101/1", name: "VEERAMALLA DHEERAJ", points: 0, floor: "1", active: true },
  { id: "AE5738", room: "101/2", name: "SOHITH SUBHANG RISHI VATTURI", points: 0, floor: "1", active: true },
  { id: "AD2352", room: "101/3", name: "BHASWRAJU VIVEK", points: 0, floor: "1", active: true },
  { id: "AD7711", room: "101/4", name: "SAMUDRALA SRIRAM PRAHARSHA", points: 0, floor: "1", active: true },
  { id: "AE4945", room: "101/5", name: "SMARAN JASTI", points: 0, floor: "1", active: true },
  { id: "AD5064", room: "101/6", name: "PABBA SATHVIK", points: 0, floor: "1", active: true },
  { id: "AD5037", room: "101/7", name: "YERRA MOHAN KARTHIKEYA", points: 0, floor: "1", active: true },
  { id: "AE7078", room: "101/8", name: "V CHAITANYA SWARWOOP", points: 0, floor: "1", active: true },
  { id: "AD9505", room: "101/9", name: "LIKHESH BEVARA", points: 0, floor: "1", active: true },
  { id: "AD4516", room: "101/10", name: "Omkar Swarup Pradhan", points: 0, floor: "1", active: true },
];

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize sample data
  await storage.initializeStudentsFromData(SAMPLE_STUDENTS);

  // Student routes
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      res.json(students);
    } catch (error) {
      console.error("Error fetching students:", error);
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const students = await storage.searchStudents(q);
      res.json(students);
    } catch (error) {
      console.error("Error searching students:", error);
      res.status(500).json({ message: "Failed to search students" });
    }
  });

  app.get("/api/students/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid student ID" });
      }
      
      const student = await storage.getStudentById(id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(student);
    } catch (error) {
      console.error("Error fetching student:", error);
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  // Points management
  app.post("/api/students/points", async (req, res) => {
    try {
      const data = updatePointsSchema.parse(req.body);
      const result = await storage.updateStudentPoints(data);
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      console.error("Error updating points:", error);
      res.status(500).json({ message: "Failed to update points" });
    }
  });

  // Rankings
  app.get("/api/rankings", async (req, res) => {
    try {
      const { grade, floor } = req.query;
      const gradeFilter = typeof grade === 'string' ? grade : undefined;
      const floorFilter = typeof floor === 'string' ? floor : undefined;
      
      const rankings = await storage.getStudentRankings(gradeFilter, floorFilter);
      res.json(rankings);
    } catch (error) {
      console.error("Error fetching rankings:", error);
      res.status(500).json({ message: "Failed to fetch rankings" });
    }
  });

  // Actions history
  app.get("/api/actions", async (req, res) => {
    try {
      const actions = await storage.getAllActions();
      res.json(actions);
    } catch (error) {
      console.error("Error fetching actions:", error);
      res.status(500).json({ message: "Failed to fetch actions" });
    }
  });

  app.get("/api/actions/student/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid student ID" });
      }
      
      const actions = await storage.getActionsByStudentId(id);
      res.json(actions);
    } catch (error) {
      console.error("Error fetching student actions:", error);
      res.status(500).json({ message: "Failed to fetch student actions" });
    }
  });

  // Statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      const actions = await storage.getAllActions();
      
      const totalStudents = students.length;
      const activeStudents = students.filter(s => s.active).length;
      const todayActions = actions.filter(a => {
        const today = new Date();
        const actionDate = new Date(a.createdAt);
        return actionDate.toDateString() === today.toDateString();
      }).length;
      
      res.json({
        totalStudents,
        activeStudents,
        todayActions
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
