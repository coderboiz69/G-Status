import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search } from "lucide-react";
import type { Student } from "@shared/schema";

interface StudentSearchProps {
  onStudentSelect: (student: Student) => void;
}

export default function StudentSearch({ onStudentSelect }: StudentSearchProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [showResults, setShowResults] = useState(false);

  const { data: searchResults, isLoading } = useQuery({
    queryKey: ["/api/students/search", { q: searchQuery }],
    queryFn: async () => {
      if (!searchQuery.trim()) return [];
      const response = await fetch(`/api/students/search?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) throw new Error("Failed to search students");
      return response.json() as Promise<Student[]>;
    },
    enabled: searchQuery.trim().length > 0,
  });

  useEffect(() => {
    setShowResults(searchQuery.trim().length > 0);
  }, [searchQuery]);

  const handleStudentSelect = (student: Student) => {
    onStudentSelect(student);
    setSearchQuery("");
    setShowResults(false);
  };

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
        <Input
          placeholder="Enter name, ID, floor, or room"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>
      
      {showResults && (
        <Card className="absolute z-10 w-full mt-1 max-h-80 overflow-y-auto">
          <CardContent className="p-2">
            {isLoading ? (
              <div className="p-3 text-sm text-slate-600">Searching...</div>
            ) : searchResults && searchResults.length > 0 ? (
              <div className="space-y-1">
                {searchResults.map((student) => (
                  <Button
                    key={student.id}
                    variant="ghost"
                    className="w-full justify-start h-auto p-3 text-left"
                    onClick={() => handleStudentSelect(student)}
                  >
                    <div className="w-full">
                      <div className="font-medium text-slate-900">{student.name}</div>
                      <div className="text-sm text-slate-500">
                        {student.studentId} • Room {student.room} • Floor {student.floor} • {student.points} pts
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            ) : (
              <div className="p-3 text-sm text-slate-600">
                No students found matching "{searchQuery}"
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
