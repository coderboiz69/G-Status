import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import StudentSearch from "@/components/student-search";
import { POSITIVE_ACTIONS, NEGATIVE_ACTIONS } from "@/lib/constants";
import type { Student } from "@shared/schema";

const formSchema = z.object({
  studentId: z.number().min(1, "Please select a student"),
  positiveAction: z.string().optional(),
  negativeAction: z.string().optional(),
  examPercentage: z.number().min(0).max(100).optional(),
}).refine(data => data.positiveAction || data.negativeAction, {
  message: "Please select either a positive or negative action",
  path: ["positiveAction"],
});

export default function AdministrationTab() {
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      studentId: 0,
      positiveAction: "",
      negativeAction: "",
      examPercentage: undefined,
    },
  });

  const updatePointsMutation = useMutation({
    mutationFn: async (data: { studentId: number; action: string; pointsChanged: number; actionType: 'positive' | 'negative' }) => {
      const response = await apiRequest("POST", "/api/students/points", data);
      return response.json();
    },
    onSuccess: () => {
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
      form.reset();
      setSelectedStudent(null);
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rankings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/actions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: "Points updated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update points. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    if (!selectedStudent) return;

    let action = "";
    let pointsChanged = 0;
    let actionType: 'positive' | 'negative' = 'positive';

    if (data.positiveAction) {
      actionType = 'positive';
      if (data.positiveAction === 'exam' && data.examPercentage !== undefined) {
        pointsChanged = Math.floor(data.examPercentage / 10); // 1 point per 10%
        action = `Exam result: ${data.examPercentage}% (+${pointsChanged})`;
      } else {
        const actionData = POSITIVE_ACTIONS.find(a => a.value === data.positiveAction);
        if (actionData) {
          // Extract points from the action value (e.g., "5-participation" -> 5)
          const pointsMatch = actionData.value.match(/^(\d+)/);
          pointsChanged = pointsMatch ? parseInt(pointsMatch[1]) : 0;
          action = actionData.label;
        } else {
          pointsChanged = 0;
          action = `Unknown positive action`;
        }
      }
    } else if (data.negativeAction) {
      actionType = 'negative';
      const actionData = NEGATIVE_ACTIONS.find(a => a.value === data.negativeAction);
      if (actionData) {
        // Extract points from the action value (e.g., "-5-dress" -> -5)
        const pointsMatch = actionData.value.match(/^(-?\d+)/);
        pointsChanged = pointsMatch ? parseInt(pointsMatch[1]) : 0;
        action = actionData.label;
      } else {
        pointsChanged = 0;
        action = `Unknown negative action`;
      }
    }

    updatePointsMutation.mutate({
      studentId: selectedStudent.id,
      action,
      pointsChanged,
      actionType,
    });
  };

  const handleStudentSelect = (student: Student) => {
    setSelectedStudent(student);
    form.setValue("studentId", student.id);
  };

  const positiveActionValue = form.watch("positiveAction");
  const showExamInput = positiveActionValue === "exam";

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Student Points Administration</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Student Search */}
        <div>
          <Label className="text-sm font-medium text-slate-700 mb-2">Search Student</Label>
          <StudentSearch onStudentSelect={handleStudentSelect} />
        </div>

        {/* Selected Student Display */}
        <Card className="bg-slate-50">
          <CardContent className="p-4">
            <h4 className="font-medium text-slate-900 mb-2">Selected Student</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-600">
                  Name: <span className="text-slate-900 font-medium">{selectedStudent?.name || "Select a student"}</span>
                </p>
                <p className="text-sm text-slate-600">
                  ID: <span className="text-slate-900 font-medium">{selectedStudent?.studentId || "-"}</span>
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600">
                  Room: <span className="text-slate-900 font-medium">{selectedStudent?.room || "-"}</span>
                </p>
                <p className="text-sm text-slate-600">
                  Current Points: <span className="text-slate-900 font-medium">{selectedStudent?.points || "-"}</span>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Points Form */}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Positive Actions */}
            <FormField
              control={form.control}
              name="positiveAction"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Positive Actions</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a positive action" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {POSITIVE_ACTIONS.map((action) => (
                        <SelectItem key={action.value} value={action.value}>
                          {action.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Exam Percentage Input */}
            {showExamInput && (
              <FormField
                control={form.control}
                name="examPercentage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Exam Percentage</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="Enter percentage (0-100)"
                        min="0"
                        max="100"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Negative Actions */}
            <FormField
              control={form.control}
              name="negativeAction"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Negative Actions</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a negative action" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {NEGATIVE_ACTIONS.map((action) => (
                        <SelectItem key={action.value} value={action.value}>
                          {action.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Submit Button */}
            <div className="flex justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  form.reset();
                  setSelectedStudent(null);
                }}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={!selectedStudent || updatePointsMutation.isPending}
              >
                {updatePointsMutation.isPending ? "Updating..." : "Update Points"}
              </Button>
            </div>
          </form>
        </Form>

        {/* Success Message */}
        {showSuccess && (
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              Points updated successfully!
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
