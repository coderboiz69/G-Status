import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Students table
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  studentId: varchar("student_id", { length: 10 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  room: varchar("room", { length: 20 }).notNull(),
  floor: varchar("floor", { length: 5 }).notNull(),
  points: integer("points").default(0).notNull(),
  grade: varchar("grade", { length: 5 }).default("").notNull(),
  remark: varchar("remark", { length: 255 }).default("").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Actions table for tracking point changes
export const actions = pgTable("actions", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  action: varchar("action", { length: 500 }).notNull(),
  pointsChanged: integer("points_changed").notNull(),
  actionType: varchar("action_type", { length: 20 }).notNull(), // 'positive' or 'negative'
  createdAt: timestamp("created_at").defaultNow().notNull(),
  adminName: varchar("admin_name", { length: 100 }).default("Admin").notNull(),
});

// Relations
export const studentsRelations = relations(students, ({ many }) => ({
  actions: many(actions),
}));

export const actionsRelations = relations(actions, ({ one }) => ({
  student: one(students, {
    fields: [actions.studentId],
    references: [students.id],
  }),
}));

// Insert schemas
export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertActionSchema = createInsertSchema(actions).omit({
  id: true,
  createdAt: true,
});

export const updatePointsSchema = z.object({
  studentId: z.number(),
  action: z.string(),
  pointsChanged: z.number(),
  actionType: z.enum(['positive', 'negative']),
});

// Types
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Action = typeof actions.$inferSelect;
export type InsertAction = z.infer<typeof insertActionSchema>;
export type UpdatePointsRequest = z.infer<typeof updatePointsSchema>;
